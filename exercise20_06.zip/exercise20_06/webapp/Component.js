sap.ui.define([
    "sap/ui/core/UIComponent",
    "listpractice/exercise2006/model/models"
], (UIComponent, models) => {
    "use strict";

    return UIComponent.extend("listpractice.exercise2006.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // enable routing
            this.getRouter().initialize();
        }
    });
});