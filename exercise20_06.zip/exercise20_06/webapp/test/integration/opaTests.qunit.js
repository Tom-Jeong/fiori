/* global QUnit */

sap.ui.require(["listpractice/exercise2006/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
