sap.ui.define([
	"list_practice/exercise20_06/test/unit/controller/ListView.controller"
], function () {
	"use strict";
});
