sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("listpractice.exercise2006.controller.App", {
      onInit() {
      }
  });
});